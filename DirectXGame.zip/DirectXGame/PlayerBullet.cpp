#include "PlayerBullet.h"
#include<cassert>
void PlayerBullet::Iniialize(Model* model, const Vector3& position) 
{ assert(model);

model_ = model;

textureHandle_ = TextureManager::Load("black.png");

worldTransform_.scale_ = {5.0f, 1.0f, 1.0f};

worldTransform_.Initialize();

worldTransform_.rotation_ = {0.0f, 0.0f, 0.0f};

worldTransform_.Initialize();

worldTransform_.translation_ = {0.0f, 0.0f, 0.0f};

worldTransform_.Initialize();

}

void PlayerBullet::Update() 
{

}

void PlayerBullet::Draw(const ViewProjection& viewProjection) {}
